// supabase/functions/zoom-create-meeting/index.ts
//
// SETUP STEPS:
// 1. Go to https://marketplace.zoom.us
// 2. Click "Develop" → "Build App" → "Server-to-Server OAuth"
// 3. Name it "UniEDD LMS" → Create
// 4. Copy: Account ID, Client ID, Client Secret
// 5. Add scope: "meeting:write:admin"
// 6. Deploy this function:
//    supabase functions deploy zoom-create-meeting
// 7. Set secrets:
//    supabase secrets set ZOOM_ACCOUNT_ID=xxx
//    supabase secrets set ZOOM_CLIENT_ID=xxx
//    supabase secrets set ZOOM_CLIENT_SECRET=xxx
// 8. Create DB webhook in Supabase:
//    Dashboard → Database → Webhooks → Create
//    Table: classes | Event: INSERT
//    URL: https://jtbcsoticxzkohykwsgs.supabase.co/functions/v1/zoom-create-meeting
//    Header: Authorization: Bearer <service_role_key>

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
)

// Get Zoom access token
async function getZoomToken(): Promise<string> {
  const id     = Deno.env.get('ZOOM_ACCOUNT_ID')!
  const client = Deno.env.get('ZOOM_CLIENT_ID')!
  const secret = Deno.env.get('ZOOM_CLIENT_SECRET')!
  const creds  = btoa(`${client}:${secret}`)

  const res = await fetch(
    `https://zoom.us/oauth/token?grant_type=account_credentials&account_id=${id}`,
    { method: 'POST', headers: { Authorization: `Basic ${creds}` } }
  )
  const data = await res.json()
  return data.access_token
}

// Create a Zoom meeting
async function createMeeting(token: string, opts: {
  topic: string
  startTime: string   // ISO format e.g. "2026-05-10T10:00:00"
  duration: number    // minutes
}) {
  const res = await fetch('https://api.zoom.us/v2/users/me/meetings', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      topic:      opts.topic,
      type:       2,
      start_time: opts.startTime,
      duration:   opts.duration,
      timezone:   'Asia/Kolkata',
      settings: {
        waiting_room:      true,
        join_before_host:  false,
        mute_upon_entry:   true,
        auto_recording:    'none',
      },
    }),
  })
  return res.json()
}

Deno.serve(async (req) => {
  try {
    const payload = await req.json()
    const cls = payload.record

    if (!cls?.id || !cls?.title) {
      return new Response('Missing class data', { status: 400 })
    }

    // Build ISO start time from class_date + start_time
    const dateStr  = cls.class_date || new Date().toISOString().slice(0, 10)
    const timeStr  = cls.start_time || '10:00'
    const startISO = `${dateStr}T${timeStr}:00`

    // Parse duration (e.g. "1h", "1.5h", "45m")
    let durationMin = 60
    if (cls.duration) {
      if (cls.duration.includes('h')) {
        durationMin = Math.round(parseFloat(cls.duration) * 60)
      } else if (cls.duration.includes('m')) {
        durationMin = parseInt(cls.duration)
      }
    }

    // Create Zoom meeting
    const token   = await getZoomToken()
    const meeting = await createMeeting(token, {
      topic:     cls.title,
      startTime: startISO,
      duration:  durationMin,
    })

    if (!meeting.join_url) {
      throw new Error(`Zoom error: ${JSON.stringify(meeting)}`)
    }

    // Save Zoom link back to the class row
    await supabase
      .from('classes')
      .update({
        meet_link:    meeting.join_url,
        zoom_host_url: meeting.start_url,
        zoom_id:      String(meeting.id),
        zoom_password: meeting.password,
      })
      .eq('id', cls.id)

    console.log(`✅ Zoom meeting created for class: ${cls.title}`)

    return new Response(
      JSON.stringify({ success: true, joinUrl: meeting.join_url }),
      { headers: { 'Content-Type': 'application/json' } }
    )
  } catch (err) {
    console.error('Zoom function error:', err)
    return new Response(
      JSON.stringify({ error: String(err) }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    )
  }
})
