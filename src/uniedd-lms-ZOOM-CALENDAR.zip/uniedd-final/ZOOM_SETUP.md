# UniEDD LMS — Zoom Auto-Link Setup Guide

When a teacher schedules a class, Zoom meeting is automatically created
and the join link appears on the calendar for all users.

---

## STEP 1 — Create Zoom Server-to-Server App (Free)

1. Go to https://marketplace.zoom.us
2. Sign in with your Zoom account
3. Click **"Develop"** → **"Build App"**
4. Choose **"Server-to-Server OAuth"** → click Create
5. Name it: `UniEDD LMS`
6. Copy these 3 values (you need them in Step 3):
   - **Account ID**
   - **Client ID**
   - **Client Secret**
7. Click **"Scopes"** tab → Add scope: `meeting:write:admin`
8. Click **"Activation"** tab → click **Activate**

---

## STEP 2 — Run SQL in Supabase

1. Go to: https://supabase.com/dashboard/project/jtbcsoticxzkohykwsgs/sql
2. Paste the entire `SUPABASE_ZOOM_CALENDAR.sql` file → Run

---

## STEP 3 — Deploy the Edge Function

Install Supabase CLI (one time only):
```bash
npm install -g supabase
```

Login and link your project:
```bash
supabase login
supabase link --project-ref jtbcsoticxzkohykwsgs
```

Deploy the function:
```bash
supabase functions deploy zoom-create-meeting
```

Set your Zoom credentials as secrets:
```bash
supabase secrets set ZOOM_ACCOUNT_ID=your_account_id_here
supabase secrets set ZOOM_CLIENT_ID=your_client_id_here
supabase secrets set ZOOM_CLIENT_SECRET=your_client_secret_here
```

---

## STEP 4 — Create Database Webhook in Supabase

1. Go to: Supabase Dashboard → **Database** → **Webhooks**
2. Click **"Create a new webhook"**
3. Fill in:
   - **Name:** zoom-create-meeting
   - **Table:** classes
   - **Events:** ✅ Insert
   - **Type:** HTTP Request
   - **URL:** `https://jtbcsoticxzkohykwsgs.supabase.co/functions/v1/zoom-create-meeting`
   - **HTTP Headers:** Add header:
     - Key: `Authorization`
     - Value: `Bearer YOUR_SERVICE_ROLE_KEY`
     (Get service role key: Supabase → Settings → API → service_role)
4. Click **Create webhook**

---

## How it works after setup

```
Teacher schedules a class
    ↓
Row inserted into "classes" table
    ↓
Supabase webhook fires automatically
    ↓
zoom-create-meeting function runs
    ↓
Zoom API creates meeting with correct date/time
    ↓
meet_link saved back to the class row
    ↓
Calendar on all dashboards shows "Join Zoom" button
```

---

## Testing

After setup, teacher schedules a class → wait 5-10 seconds →
refresh the calendar → the "Join Zoom" button should appear.

If it doesn't appear, check:
- Supabase → Edge Functions → zoom-create-meeting → Logs
- Make sure all 3 Zoom secrets are set correctly
