-- ============================================================
--  UNIEDD LMS — ADD ZOOM COLUMNS + CALENDAR SUPPORT
--  Paste in: Supabase → SQL Editor → New Query → Run
-- ============================================================

-- Add Zoom columns to classes table
ALTER TABLE classes ADD COLUMN IF NOT EXISTS zoom_id       TEXT;
ALTER TABLE classes ADD COLUMN IF NOT EXISTS zoom_password  TEXT;
ALTER TABLE classes ADD COLUMN IF NOT EXISTS zoom_host_url  TEXT;

-- Make sure meet_link column exists (join URL)
ALTER TABLE classes ADD COLUMN IF NOT EXISTS meet_link TEXT;

-- Add student_id column to profiles if missing
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS student_id TEXT;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS phone      TEXT;

-- Add student_id to leads if missing
ALTER TABLE leads ADD COLUMN IF NOT EXISTS student_id TEXT;

-- Index for faster calendar queries
CREATE INDEX IF NOT EXISTS idx_classes_date    ON classes(class_date);
CREATE INDEX IF NOT EXISTS idx_events_date     ON events(year, month, day);
CREATE INDEX IF NOT EXISTS idx_classes_teacher ON classes(teacher_id);

-- ============================================================
--  DONE
-- ============================================================
